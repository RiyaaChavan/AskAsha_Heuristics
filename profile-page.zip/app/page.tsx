"use client"

import { useState, useEffect } from "react"
import Navbar from "@/components/navbar"
import ProfileView from "@/components/profile-view"
import { Poppins } from "next/font/google"

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
})

export default function Home() {
  const [loading, setLoading] = useState(true)

  // Mock profile data to ensure we see something in the preview
  const profile = {
    name: "riya",
    email: "riyaachavan08@gmail.com",
    phone: "8104542617",
    location: "Mumbai",
    locationPreference: "remote",
    gender: "female",
    education: "Bachelors",
    professionalStage: "student",
    resumeFile: "Riya-Chavan-Work.pdf",
    resumeUpdated: "May 20, 2025",
  }

  // Mock skills array based on the screenshot
  const skills = [
    "Python",
    "Java",
    "C++",
    "Pandas",
    "NumPy",
    "Matplotlib",
    "Seaborn",
    "Scikit-learn",
    "TensorFlow",
    "OpenCV",
    "SpaCy",
    "NLTK",
    "OpenAI",
    "Gemini",
    "Llama-Index",
    "LangChain",
    "Transformers",
    "HTML",
    "CSS",
    "React",
    "Node.js",
    "Streamlit",
    "Flask",
    "Fast API",
    "Kafka",
    "Spark",
    "Docker",
    "AWS",
    "GCP",
    "Grafana",
    "SQL",
    "Cassandra",
    "MongoDB",
    "AstraDB",
    "Pinecone",
    "LangFlow",
    "BeautifulSoup",
    "Tableau",
    "PowerBI",
    "Arduino",
    "AutoCAD",
    "Team Collaboration",
    "Effective Communication",
    "CNNs",
    "PSO",
    "ReliefF Algorithm",
    "HDFB",
    "Llama",
    "Jira",
    "BM25",
    "Telegram BOT",
    "SupaBase",
    "BERT",
    "RAG",
    "S3",
    "Next.js",
    "Cloudflare",
    "Web Scrapping",
    "Elastic-Search",
    "PostgreSQL",
    "Tweepy",
    "Mastodon API",
    "TF-IDF",
    "Cosine Similarity",
    "Apache Spark",
    "Big Data",
    "Data Pipeline",
  ]

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  if (loading) {
    return (
      <div className={`min-h-screen flex items-center justify-center bg-[#934f73] ${poppins.className}`}>
        <div className="w-16 h-16 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  return (
    <div className={`min-h-screen bg-[#f5f5f5] ${poppins.className}`}>
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <ProfileView profile={profile} skills={skills} />
      </div>
    </div>
  )
}
