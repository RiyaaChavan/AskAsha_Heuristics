"use client"

import { useSearchParams } from "next/navigation"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function ResumePreviewPage() {
  const searchParams = useSearchParams()
  const fileName = searchParams.get("file") || "resume.pdf"

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <header className="bg-[#934f73] text-white py-4 px-6">
        <div className="container mx-auto flex items-center">
          <Link href="/" className="flex items-center text-white hover:text-white/80">
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back to Profile
          </Link>
          <h1 className="text-xl font-semibold ml-4">Resume Preview: {fileName}</h1>
        </div>
      </header>

      <main className="flex-1 container mx-auto p-6">
        <div className="bg-white rounded-lg shadow-md p-6 h-full flex flex-col">
          <div className="text-center py-12 border-2 border-dashed border-gray-300 rounded-lg flex-1 flex flex-col items-center justify-center">
            <div className="mb-6">
              <svg
                className="w-24 h-24 text-gray-400 mx-auto"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                ></path>
              </svg>
            </div>
            <h2 className="text-2xl font-medium text-gray-700 mb-2">{fileName}</h2>
            <p className="text-gray-500 mb-6">This is a preview of your resume document.</p>
            <p className="text-gray-400 text-sm max-w-md">
              In a real application, the actual PDF or document would be displayed here using a document viewer
              component.
            </p>
          </div>
        </div>
      </main>
    </div>
  )
}
