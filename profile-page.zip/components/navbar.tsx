import Link from "next/link"
import { User } from "lucide-react"

export default function Navbar() {
  return (
    <header className="bg-[#934f73] text-white py-4 px-6">
      <div className="container mx-auto flex items-center justify-between">
        <Link href="/" className="text-2xl font-bold">
          AskAsha
        </Link>

        <nav className="hidden md:flex items-center space-x-6">
          <Link href="/job-hunt" className="hover:text-white/80 transition-colors">
            Job Hunt
          </Link>
          <Link href="/event-hub" className="hover:text-white/80 transition-colors">
            Event Hub
          </Link>
          <Link href="/my-roadmap" className="hover:text-white/80 transition-colors">
            My Roadmap
          </Link>
          <Link href="/interview-assistant" className="hover:text-white/80 transition-colors">
            Interview Assistant
          </Link>
          <Link href="/career-coach" className="hover:text-white/80 transition-colors">
            Career Coach-Help Desk
          </Link>
        </nav>

        <button className="rounded-full bg-white/10 p-2">
          <User className="h-5 w-5 text-white" />
          <span className="sr-only">Profile</span>
        </button>
      </div>
    </header>
  )
}
