"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { apiService } from "@/lib/api-service"
import Navbar from "@/components/navbar"

export default function ProfileSetup() {
  const router = useRouter()

  // Get userId and email from localStorage (set after signup/login)
  const userId = typeof window !== "undefined" ? localStorage.getItem("userId") || "" : ""
  const storedEmail = typeof window !== "undefined" ? localStorage.getItem("email") || "" : ""

  const [loading, setLoading] = useState(true)
  const [step, setStep] = useState(1)
  const [error, setError] = useState("")
  const [submitting, setSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    email: storedEmail,
    phone: "",
    location: "",
    locationPreference: "",
    gender: "",
    education: "",
    professionalStage: "",
    resume: null as File | null,
    skills: [] as string[],
  })

  useEffect(() => {
    // Check if the profile already exists; if yes, navigate to /jobsearch immediately
    const checkProfile = async () => {
      if (!userId) {
        setLoading(false)
        return
      }
      try {
        const data = await apiService.getProfile(userId)
        if (data && data.name) {
          router.push("/jobsearch")
        }
      } catch (err) {
        console.error("Error checking profile:", err)
      } finally {
        setLoading(false)
      }
    }
    checkProfile()
  }, [userId, router])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setFormData((prev) => ({
        ...prev,
        resume: file,
      }))
    }
  }

  const handleSkillsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const skillsArray = e.target.value.split(",").map((skill) => skill.trim())
    setFormData((prev) => ({
      ...prev,
      skills: skillsArray,
    }))
  }

  const nextStep = () => {
    if (step < 3) setStep(step + 1)
  }

  const prevStep = () => {
    if (step > 1) setStep(step - 1)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!userId) {
      setError("User not authenticated")
      return
    }

    setSubmitting(true)
    setError("")
    try {
      const formDataToSend = new FormData()
      Object.entries(formData).forEach(([key, value]) => {
        if (key !== "resume" && key !== "skills" && value !== null) {
          formDataToSend.append(key, String(value))
        }
      })

      // Handle skills array
      if (formData.skills.length > 0) {
        formDataToSend.append("skills", formData.skills.join(","))
      }

      if (formData.resume instanceof File) {
        formDataToSend.append("resume", formData.resume)
      }
      formDataToSend.append("uid", userId)

      const response = await apiService.createProfile(formDataToSend)

      if (response.status === "success" || response.message === "Profile created successfully") {
        localStorage.setItem("profileCreated", "true")
        localStorage.setItem("userId", userId)
        router.push("/jobsearch")
      } else {
        setError(response.error || response.message || "Failed to create profile")
      }
    } catch (err) {
      console.error("Profile submission error:", err)
      setError("Error creating profile. Please try again.")
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-primary">
        <div className="w-16 h-16 border-4 border-primary-foreground border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  const progressPercentage = (step / 3) * 100

  return (
    <div className="min-h-screen bg-primary">
      <Navbar />
      <div className="container mx-auto px-4 py-8 max-w-md">
        <h2 className="text-3xl font-bold text-white text-center mb-8">Complete Your Profile</h2>

        {/* Progress bar */}
        <div className="mb-8">
          <div className="h-2 bg-white/20 rounded-full overflow-hidden">
            <div
              className="h-full bg-green-500 rounded-full transition-all duration-300"
              style={{ width: `${progressPercentage}%` }}
            ></div>
          </div>
          <div className="flex justify-between mt-2 text-white/70">
            <span className={step >= 1 ? "text-white font-medium" : ""}>Personal</span>
            <span className={step >= 2 ? "text-white font-medium" : ""}>Location</span>
            <span className={step >= 3 ? "text-white font-medium" : ""}>Professional</span>
          </div>
        </div>

        <motion.div
          className="bg-white rounded-xl shadow-lg p-6 md:p-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <form onSubmit={handleSubmit}>
            {step === 1 && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-primary text-base">
                    Name
                  </Label>
                  <Input id="name" name="name" value={formData.name} onChange={handleInputChange} required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-primary text-base">
                    Email
                  </Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-primary text-base">
                    Phone
                  </Label>
                  <Input
                    id="phone"
                    name="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="location" className="text-primary text-base">
                    Location
                  </Label>
                  <Input
                    id="location"
                    name="location"
                    value={formData.location}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="locationPreference" className="text-primary text-base">
                    Location Preference
                  </Label>
                  <Select
                    value={formData.locationPreference}
                    onValueChange={(value) => handleSelectChange("locationPreference", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select preference" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="remote">Remote</SelectItem>
                      <SelectItem value="hybrid">Hybrid</SelectItem>
                      <SelectItem value="onsite">Onsite</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="gender" className="text-primary text-base">
                    Gender
                  </Label>
                  <Select value={formData.gender} onValueChange={(value) => handleSelectChange("gender", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="education" className="text-primary text-base">
                    Education
                  </Label>
                  <Input
                    id="education"
                    name="education"
                    value={formData.education}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="professionalStage" className="text-primary text-base">
                    Professional Stage
                  </Label>
                  <Select
                    value={formData.professionalStage}
                    onValueChange={(value) => handleSelectChange("professionalStage", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select stage" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="student">Student</SelectItem>
                      <SelectItem value="entry">Entry Level</SelectItem>
                      <SelectItem value="mid">Mid Level</SelectItem>
                      <SelectItem value="senior">Senior Level</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="skills" className="text-primary text-base">
                    Skills (comma separated)
                  </Label>
                  <Input
                    id="skills"
                    name="skills"
                    placeholder="Python, Java, React, etc."
                    value={formData.skills.join(", ")}
                    onChange={handleSkillsChange}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="resume" className="text-primary text-base">
                    Resume
                  </Label>
                  <Input
                    id="resume"
                    name="resume"
                    type="file"
                    onChange={handleFileChange}
                    accept=".pdf,.doc,.docx"
                    required
                    className="cursor-pointer"
                  />
                </div>
              </motion.div>
            )}

            <div className="flex justify-end gap-4 mt-8">
              {step > 1 && (
                <Button
                  type="button"
                  onClick={prevStep}
                  variant="outline"
                  className="border-primary text-primary hover:bg-primary/5"
                >
                  Previous
                </Button>
              )}

              {step < 3 ? (
                <Button type="button" onClick={nextStep} className="bg-primary hover:bg-primary/90">
                  Next
                </Button>
              ) : (
                <Button type="submit" className="bg-primary hover:bg-primary/90" disabled={submitting}>
                  {submitting ? "Submitting..." : "Complete Profile"}
                </Button>
              )}
            </div>

            {error && <p className="mt-4 text-red-500 text-sm">{error}</p>}
          </form>
        </motion.div>
      </div>
    </div>
  )
}
