import { User } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"

interface ProfileCardProps {
  profile: {
    name: string
    email: string
    phone: string
    location: string
    locationPreference: string
    gender: string
    education: string
    professionalStage: string
  }
  skills: string[]
}

export default function ProfileCard({ profile, skills }: ProfileCardProps) {
  // Capitalize first letter of each word
  const capitalize = (str: string) => {
    return str
      .split(" ")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(" ")
  }

  return (
    <Card className="max-w-4xl mx-auto bg-white rounded-lg overflow-hidden shadow-lg">
      <CardContent className="p-0">
        <div className="grid md:grid-cols-[300px_1fr] gap-6">
          {/* Left column - User info */}
          <div className="flex flex-col items-center p-8 border-r border-gray-200">
            <div className="relative mb-4">
              <div className="w-32 h-32 rounded-full bg-gray-100 flex items-center justify-center">
                <User className="h-16 w-16 text-gray-400" />
              </div>
            </div>

            <h2 className="text-2xl font-medium text-primary mb-2">{profile.name || "User"}</h2>

            <p className="text-green-500 mb-6">{profile.email || "email@example.com"}</p>

            <div className="text-center text-gray-500 mb-2">{profile.professionalStage || "Professional"}</div>

            <div className="w-full mt-6">
              <div className="mb-6">
                <h3 className="text-gray-500 mb-2">Phone</h3>
                <p className="text-lg font-medium text-gray-800">{profile.phone || "Not provided"}</p>
              </div>

              <div className="mb-6">
                <h3 className="text-gray-500 mb-2">Location</h3>
                <p className="text-lg font-medium text-gray-800">{profile.location || "Not provided"}</p>
              </div>

              <div className="mb-6">
                <h3 className="text-gray-500 mb-2">Gender</h3>
                <p className="text-lg font-medium text-gray-800">{capitalize(profile.gender) || "Not provided"}</p>
              </div>
            </div>
          </div>

          {/* Right column - Professional info */}
          <div className="p-8">
            <h2 className="text-2xl font-semibold text-primary mb-8">Professional Information</h2>

            <div className="grid md:grid-cols-2 gap-8 mb-8">
              <div>
                <h3 className="text-gray-500 mb-2">Education</h3>
                <p className="text-lg font-medium text-gray-800">{profile.education || "Not provided"}</p>
              </div>

              <div>
                <h3 className="text-gray-500 mb-2">Location Preference</h3>
                <p className="text-lg font-medium text-gray-800">{profile.locationPreference || "Not provided"}</p>
              </div>
            </div>

            <div className="mb-6">
              <h3 className="text-xl font-semibold text-primary mb-4">Skills & Expertise</h3>

              <div className="flex flex-wrap gap-2">
                {skills && skills.length > 0 ? (
                  skills.map((skill, index) => (
                    <Badge
                      key={index}
                      className="bg-green-100 hover:bg-green-200 text-green-800 px-3 py-1 rounded-full text-sm"
                    >
                      {skill.trim()}
                    </Badge>
                  ))
                ) : (
                  <p className="text-gray-500">No skills added yet</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
