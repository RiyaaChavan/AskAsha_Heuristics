"use client"

import { useState } from "react"
import { User, MapPin, Phone, GraduationCap } from "lucide-react"
import ResumeSection from "./resume-section"

interface ProfileViewProps {
  profile: {
    name: string
    email: string
    phone: string
    location: string
    locationPreference: string
    gender: string
    education: string
    professionalStage: string
    resumeFile: string
    resumeUpdated: string
  }
  skills: string[]
}

export default function ProfileView({ profile, skills }: ProfileViewProps) {
  const [activeTab, setActiveTab] = useState<"profile" | "resume">("profile")

  // Capitalize first letter of each word
  const capitalize = (str: string) => {
    return str
      .split(" ")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(" ")
  }

  return (
    <div className="grid md:grid-cols-[300px_1fr] gap-6">
      {/* Left sidebar */}
      <div className="space-y-6">
        {/* Profile card */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="bg-[#934f73] h-24 relative">
            <div className="absolute left-1/2 transform -translate-x-1/2 top-12 w-24 h-24 rounded-full bg-white flex items-center justify-center border-4 border-white">
              <User className="h-12 w-12 text-[#934f73]" />
            </div>
          </div>

          <div className="pt-16 pb-6 px-6 text-center">
            <h2 className="text-xl font-medium mb-1">User</h2>
            <p className="text-[#87c05a] text-sm mb-4">
              <span className="inline-flex items-center">
                <span className="mr-1">No email available</span>
              </span>
            </p>
            <div className="inline-block bg-[#f5f5f5] px-3 py-1 rounded-full text-sm text-gray-600">
              {profile.professionalStage}
            </div>
          </div>

          <div className="border-t border-gray-100 px-6 py-4">
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="text-[#934f73] mr-3 mt-0.5">
                  <Phone className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-gray-500 text-xs mb-1">PHONE</p>
                  <p className="text-gray-800">{profile.phone || "N/A"}</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="text-[#934f73] mr-3 mt-0.5">
                  <MapPin className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-gray-500 text-xs mb-1">LOCATION</p>
                  <p className="text-gray-800">{profile.location || "N/A"}</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="text-[#934f73] mr-3 mt-0.5">
                  <User className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-gray-500 text-xs mb-1">GENDER</p>
                  <p className="text-gray-800">{capitalize(profile.gender) || "N/A"}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <button
            className={`w-full text-left px-6 py-4 border-l-4 ${
              activeTab === "profile" ? "border-[#934f73] bg-[#faf5f8]" : "border-transparent"
            }`}
            onClick={() => setActiveTab("profile")}
          >
            <span className="font-medium text-[#934f73]">My Profile</span>
          </button>

          <button className="w-full text-left px-6 py-4 border-l-4 border-transparent hover:bg-gray-50">
            <span className="font-medium text-gray-600">Update Profile</span>
          </button>
        </div>
      </div>

      {/* Main content */}
      <div className="space-y-6">
        {/* Professional Information */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden p-6">
          <h2 className="text-xl font-semibold text-[#934f73] mb-6">Professional Information</h2>
          <div className="border-b border-gray-100 w-16 mb-6 border-[#87c05a] border-2"></div>

          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <div className="flex items-start">
              <div className="text-[#87c05a] mr-3 mt-0.5">
                <GraduationCap className="h-5 w-5" />
              </div>
              <div>
                <p className="text-gray-500 text-sm uppercase mb-1">Education</p>
                <p className="text-gray-800 font-medium">{profile.education || "Not specified"}</p>
              </div>
            </div>

            <div className="flex items-start">
              <div className="text-[#87c05a] mr-3 mt-0.5">
                <MapPin className="h-5 w-5" />
              </div>
              <div>
                <p className="text-gray-500 text-sm uppercase mb-1">Location Preference</p>
                <p className="text-gray-800 font-medium">{profile.locationPreference || "Not specified"}</p>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-[#934f73] mb-4">Skills & Expertise</h3>

            <div className="flex flex-wrap gap-2">
              {skills.map((skill, index) => (
                <span key={index} className="bg-[#87c05a]/10 text-[#5a8c2b] px-3 py-1 rounded-full text-sm">
                  {skill}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Resume Section */}
        <ResumeSection resumeFile={profile.resumeFile} resumeUpdated={profile.resumeUpdated} />
      </div>
    </div>
  )
}
