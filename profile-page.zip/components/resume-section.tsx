"use client"

import type React from "react"

import { useState } from "react"
import { FileText, Calendar, Upload, X, Check } from "lucide-react"

interface ResumeSectionProps {
  resumeFile: string
  resumeUpdated: string
}

export default function ResumeSection({ resumeFile, resumeUpdated }: ResumeSectionProps) {
  const [isUpdating, setIsUpdating] = useState(false)
  const [newFile, setNewFile] = useState<File | null>(null)
  const [uploadSuccess, setUploadSuccess] = useState(false)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setNewFile(file)
    }
  }

  const handleViewResume = () => {
    // In a real app, this would open the actual file
    // For demo purposes, we'll just open a new window
    window.open(`/resume-preview?file=${resumeFile}`, "_blank")
  }

  const handleUpdateClick = () => {
    setIsUpdating(true)
  }

  const handleCancelUpdate = () => {
    setIsUpdating(false)
    setNewFile(null)
  }

  const handleSaveChanges = () => {
    // In a real app, this would upload the file to the server
    // For demo purposes, we'll just show a success message
    if (newFile) {
      setUploadSuccess(true)
      setTimeout(() => {
        setUploadSuccess(false)
        setIsUpdating(false)
        setNewFile(null)
      }, 2000)
    }
  }

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden p-6">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          <div className="text-[#87c05a] mr-3">
            <FileText className="h-5 w-5" />
          </div>
          <h2 className="text-xl font-semibold text-[#934f73]">Resume</h2>
        </div>

        <div className="flex items-center text-[#87c05a] bg-[#87c05a]/10 px-3 py-1 rounded-full text-sm">
          <Calendar className="h-4 w-4 mr-1" />
          <span>Updated: {resumeUpdated}</span>
        </div>
      </div>

      <div className="border-b border-gray-100 w-16 mb-6 border-[#87c05a] border-2"></div>

      {!isUpdating ? (
        <div className="grid md:grid-cols-2 gap-6">
          <div className="border border-gray-200 rounded-lg p-6 flex items-center justify-center bg-gray-50">
            <div className="text-center">
              <div className="flex justify-center mb-4">
                <FileText className="h-12 w-12 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium mb-2">Resume preview</h3>
              <p className="text-gray-500 mb-4">{resumeFile}</p>
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <button
              onClick={handleViewResume}
              className="w-full py-3 bg-[#934f73] text-white rounded-md hover:bg-[#834f73] transition-colors"
            >
              View Resume
            </button>

            <button
              onClick={handleUpdateClick}
              className="w-full py-3 border border-[#934f73] text-[#934f73] rounded-md hover:bg-[#faf5f8] transition-colors"
            >
              Update Resume
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 flex flex-col items-center justify-center bg-gray-50">
            {newFile ? (
              <div className="text-center">
                <div className="flex justify-center mb-4">
                  <FileText className="h-12 w-12 text-[#87c05a]" />
                </div>
                <h3 className="text-lg font-medium mb-2">File selected</h3>
                <p className="text-gray-500 mb-4">{newFile.name}</p>
                <button
                  onClick={() => setNewFile(null)}
                  className="text-red-500 flex items-center justify-center mx-auto"
                >
                  <X className="h-4 w-4 mr-1" />
                  Remove
                </button>
              </div>
            ) : (
              <div className="text-center">
                <div className="flex justify-center mb-4">
                  <Upload className="h-12 w-12 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium mb-2">Upload new resume</h3>
                <p className="text-gray-500 mb-4">Drag and drop or click to browse</p>
                <input
                  type="file"
                  id="resume-upload"
                  className="hidden"
                  accept=".pdf,.doc,.docx"
                  onChange={handleFileChange}
                />
                <label
                  htmlFor="resume-upload"
                  className="px-4 py-2 bg-[#87c05a] text-white rounded-md hover:bg-[#76a94a] transition-colors cursor-pointer"
                >
                  Browse Files
                </label>
              </div>
            )}
          </div>

          <div className="flex gap-4">
            <button
              onClick={handleCancelUpdate}
              className="flex-1 py-3 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>

            <button
              onClick={handleSaveChanges}
              disabled={!newFile || uploadSuccess}
              className={`flex-1 py-3 rounded-md flex items-center justify-center ${
                !newFile || uploadSuccess
                  ? "bg-gray-300 text-gray-500 cursor-not-allowed"
                  : "bg-[#87c05a] text-white hover:bg-[#76a94a]"
              } transition-colors`}
            >
              {uploadSuccess ? (
                <>
                  <Check className="h-4 w-4 mr-2" />
                  Saved!
                </>
              ) : (
                "Save Changes"
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
