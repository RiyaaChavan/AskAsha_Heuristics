// Mock API service for demonstration
// Replace with actual API calls in production

export const apiService = {
  async getProfile(userId: string) {
    // In a real app, this would be an API call
    try {
      // For demo purposes, check localStorage first
      const storedProfile = localStorage.getItem(`profile_${userId}`)
      if (storedProfile) {
        return JSON.parse(storedProfile)
      }

      // Mock profile data for demonstration
      const mockProfile = {
        name: "riya",
        email: "riyaachavan08@gmail.com",
        phone: "8104542617",
        location: "Mumbai",
        locationPreference: "remote",
        gender: "female",
        education: "Bachelors",
        professionalStage: "student",
        skills: [
          "Python",
          "Java",
          "C++",
          "Pandas",
          "NumPy",
          "Matplotlib",
          "Seaborn",
          "TensorFlow",
          "OpenCV",
          "SpaCy",
          "NLTK",
          "OpenAI",
          "Gemini",
          "Llama-Index",
          "LangChain",
          "Transformers",
          "HTML",
          "CSS",
          "React",
          "Node.js",
          "Streamlit",
          "Flask",
          "Fast API",
          "Kafka",
          "Spark",
          "Docker",
          "AWS",
          "GCP",
          "Grafana",
          "SQL",
          "Cassandra",
          "MongoDB",
          "AstraDB",
          "Pinecone",
          "LangFlow",
          "BeautifulSoup",
          "Tableau",
          "PowerBI",
          "Arduino",
          "AutoCAD",
          "Team Collaboration",
          "Effective Communication",
          "CNNs",
          "PSO",
          "ReliefF Algorithm",
          "HDFB",
          "MongoDB",
          "Scikit-learn",
          "Llama",
          "AstraDB",
          "Cassandra",
          "React",
          "Jira",
          "BM25",
          "Telegram BOT",
          "SupaBase",
          "Langchain",
          "BERT",
          "RAG",
          "S3",
          "Next.js",
          "Cloudflare",
          "Web Scrapping",
          "Elastic-Search",
          "PostgreSQL",
          "Tweepy",
          "Mastodon API",
          "TF-IDF",
          "Cosine Similarity",
          "Apache Spark",
          "Big Data",
          "Data Pipeline",
        ],
      }

      // Store in localStorage for demo purposes
      localStorage.setItem(`profile_${userId}`, JSON.stringify(mockProfile))

      return mockProfile
    } catch (error) {
      console.error("Error fetching profile:", error)
      throw error
    }
  },

  async createProfile(formData: FormData) {
    // In a real app, this would be an API call
    try {
      const userId = formData.get("uid") as string

      // Create a profile object from form data
      const profile: Record<string, any> = {}
      formData.forEach((value, key) => {
        if (key !== "resume") {
          profile[key] = value
        }
      })

      // For demo purposes, store in localStorage
      localStorage.setItem(`profile_${userId}`, JSON.stringify(profile))

      return { status: "success", message: "Profile created successfully" }
    } catch (error) {
      console.error("Error creating profile:", error)
      return { status: "error", error: "Failed to create profile" }
    }
  },
}
